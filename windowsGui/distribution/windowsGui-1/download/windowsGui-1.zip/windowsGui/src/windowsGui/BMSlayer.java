package windowsGui;

public class BMSlayer extends BMS{
	BMS Bms;
	BMSlayer(BMS b){
		
		
	};
	
	
};
